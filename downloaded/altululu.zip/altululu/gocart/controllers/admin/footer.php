<div class='clear'></div>
<div class="footer-wrap">
<div id="footer">
	<div class="wrapper">
      <div class="column col-1">
        <h3>Information</h3>
        <ul>
                    <li><a class="" href="<?php echo site_url('about-us'); ?>"><?php echo lang('about') ?></a></li>
                    <li><a class="" href="<?php echo site_url('delivery'); ?>"><?php echo lang('delivery') ?></a></li>
                    <li><a class="" href="<?php echo site_url('privacy-policy'); ?>"><?php echo lang('privacy_policy') ?></a></li>
                    <li><a class="" href="<?php echo site_url('terms-condition'); ?>"><?php echo lang('terms_cond') ?></a></li>
                  </ul>
      </div>
      <div class="column col-2">
        <h3>Customer Service</h3>
        <ul>
          <li><a class="" href="<?php echo site_url('contact-us'); ?>"><?php echo lang('cntct_us') ?></a></li>
          <li><a class="" href="<?php echo site_url('cart/view_cart'); ?>"><?php echo lang('return') ?></a></li>
          <li><a class="" href="<?php echo site_url('cart/view_cart'); ?>"><?php echo lang('site_map') ?></a></li>
        </ul>
      </div>
      <div class="column col-3">
        <h3>Extras</h3>
        <ul>
          <li><a class="" href="<?php echo site_url('cart/view_cart'); ?>"><?php echo lang('brands') ?></a></li>
          <li><a class="" href="<?php echo site_url('cart/view_cart'); ?>"><?php echo lang('gift_voucher') ?></a></li>
          <li><a class="" href="<?php echo site_url('cart/empty_cart'); ?>"><?php echo lang('empty_cart') ?></a></li>
          </ul>
      </div>
      <div class="column col-4">
        <h3>My Account</h3>
        <ul>
          <li><a class="" href="<?php echo site_url('cart/view_cart'); ?>"><?php echo lang('account') ?></a></li>
          <li><a class="" href="<?php echo site_url('cart/view_cart'); ?>"><?php echo lang('order_history') ?></a></li>
          <li><a class="" href="<?php echo site_url('cart/view_cart'); ?>"><?php echo lang('wish_list') ?></a></li>
          <li><a class="" href="<?php echo site_url('cart/view_cart'); ?>"><?php echo lang('news_letter') ?></a></li>
        </ul>
      </div>
      <div class="column col-5">
        <h3>Follow Us</h3>
        <ul>
          <li class="fb"><a href="http://facebook.com/"></a></li>
          <li class="twitter"><a href="http://twitter.com/"></a></li>
        </ul>
      </div>
  </div>
  
</div>
<div class="wrapper">
      <div id="powered">Powered By <a href="http://www.phoenixsolutions.com.np/" onclick="blank">PhoenixSolutions</a> onlineStore © 2014</div>
  </div>
</div>
</div>
</div>
</div>
</body>
</html>