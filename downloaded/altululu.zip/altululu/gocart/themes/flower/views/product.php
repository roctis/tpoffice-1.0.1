<div class="main-container">
    <div id="container">
        <?php include_once 'breadcrumb.php'; ?>
        <div id="column-left">
            <?php include_once 'sidebar_category.php'; ?>
        </div>
        <div id="content">  
            <div class="product-info">
                <div class="wrapper indent-bot">
                    <?php
                    $photo = theme_img('no_picture.png', lang('no_image_available'));
                    $product->images = array_values($product->images);

                    if (!empty($product->images[0])) {
                        $primary = $product->images[0];
                        foreach ($product->images as $photo) {
                            if (isset($photo->primary)) {
                                $primary = $photo;
                            }
                        }

                        $photo = $primary->filename;
                        $alt = $product->seo_title;
                    }
                    ?>

                    <?php if (count($product->images) >= 1): ?>
                        <div class="fleft left spacing">
                            <?php foreach ($product->images as $image): ?>  
                                <div class="zoom-top"><a href="<?php echo base_url('uploads/images/full/' . $image->filename); ?>" title="one" data-gal="prettyPhoto[gallery]"><img src="<?php echo base_url('uploads/images/sthumbnails/' . $image->filename); ?>" title="one-a" alt="<?php echo $image->alt; ?>"></a></div>
                            <?php endforeach ?>  
                            <div class="image"> 
                                <div id="wrap" style="top:0px;z-index:9999;position:relative;">
                                    <a style="position: relative; display: block;" href="<?php echo base_url('uploads/images/full/' . $photo); ?>" title="one" class="cloud-zoom" id="zoom1" rel="position: 'right'">
                                        <img style="display: block;" src="<?php echo base_url('uploads/images/full/' . $photo); ?>" title="zoomin look" alt="Dolor sit amet conse">
                                    </a>
                                    <div class="mousetrap" style="background-image: url(&quot;.&quot;); z-index: 999; position: absolute; width: 300px; height: 300px; left: 0px; top: 0px; cursor: move;"></div>
                                </div>

                            </div>

                            <div class="image-additional" style='z-index:111;'>

                                <?php foreach ($product->images as $image): ?>  
                                    <a href="<?php echo base_url('uploads/images/full/' . $image->filename); ?>" class="cloud-zoom-gallery" rel="useZoom: 'zoom1', smallImage: '<?php echo base_url("uploads/images/full/" . $image->filename); ?>' "><img src="<?php echo base_url('uploads/images/sthumbnails/' . $image->filename); ?>" alt="<?php echo $image->alt; ?>"></a>
                                <?php endforeach; ?>


                            </div>

                        </div>

                    <?php endif; ?>
                    <div class="extra-wrap">
                        <h1><?php echo $product->name; ?></h1>
                        <div class="description">
                            <?php if (!empty($product->sku)): ?><span><?php echo lang('sku'); ?>: <?php echo $product->sku; ?></span><?php endif; ?><br>
                            <div class="padd-avalib"> <div class="extra-wrap"> <span class="prod-stock-2">Availability:</span>
                                    <div class="prod-stock" style="font-size:11px">
                                        <?php if ((bool) $product->track_stock && $product->quantity < 1 && config_item('inventory_enabled')): ?>
                                            <div><?php echo lang('out_of_stock'); ?></div>
                                        <?php elseif (!(bool) $product->track_stock && config_item('inventory_enabled')) : ?>
                                            <div><?php echo 'In'; ?><br>Stock</div>
                                        <?php else : ?>
                                            <div style="padding-bottom:5px;"><?php echo $product->quantity; ?><br>units</div> 
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="price">
                            <span class="text-price">Price:</span>
                            <?php if ($product->saleprice > 0): ?>
                                <span class="price-new"><?php echo format_currency($product->saleprice); ?></span>
                                <span class="price-old"><?php echo format_currency($product->price); ?></span>
                            <?php else : ?>
                                <span class="price-new"><?php echo format_currency($product->price); ?></span> 
                            <?php endif; ?>
<!--                                <span class="price-tax">Ex Tax: £172.77</span>-->
                            <br>
                        </div>
                        <div class="cart">
                            <div class="prod-row">
                                <div class="cart-top">
                                    <div class="cart-top-padd">
                                        <?php echo form_open('cart/add_to_cart', 'class="form-horizontal"'); ?>
                                        <input type="hidden" name="cartkey" value="<?php echo $this->session->flashdata('cartkey'); ?>" />
                                        <input type="hidden" name="id" value="<?php echo $product->id ?>"/>
                                        <fieldset>
                                            <?php if (count($options) > 0): ?>
                                                <?php
                                                foreach ($options as $option):
                                                    $required = '';
                                                    if ($option->required) {
                                                        $required = ' <p class="help-block">Required</p>';
                                                    }
                                                    ?>
                                                    <div>
                                                        <label><?php echo $option->name; ?></label>
                                                        <?php
                                                        /*
                                                          this is where we generate the options and either use default values, or previously posted variables
                                                          that we either returned for errors, or in some other releases of Go Cart the user may be editing
                                                          and entry in their cart.
                                                         */

                                                        //if we're dealing with a textfield or text area, grab the option value and store it in value
                                                        if ($option->type == 'checklist') {
                                                            $value = array();
                                                            if ($posted_options && isset($posted_options[$option->id])) {
                                                                $value = $posted_options[$option->id];
                                                            }
                                                        } else {
                                                            if (isset($option->values[0])) {
                                                                $value = $option->values[0]->value;
                                                                if ($posted_options && isset($posted_options[$option->id])) {
                                                                    $value = $posted_options[$option->id];
                                                                }
                                                            } else {
                                                                $value = false;
                                                            }
                                                        }

                                                        if ($option->type == 'textfield'):
                                                            ?>
                                                            <div>
                                                                <input type="text" name="option[<?php echo $option->id; ?>]" value="<?php echo $value; ?>" class="span4"/>
                                                                <?php echo $required; ?>
                                                            </div>
                                                        <?php elseif ($option->type == 'textarea'): ?>
                                                            <div>
                                                                <textarea class="span4" name="option[<?php echo $option->id; ?>]"><?php echo $value; ?></textarea>
                                                                <?php echo $required; ?>
                                                            </div>
                                                        <?php elseif ($option->type == 'droplist'): ?>
                                                            <div>
                                                                <select name="option[<?php echo $option->id; ?>]">
                                                                    <option value=""><?php echo lang('choose_option'); ?></option>

                                                                    <?php
                                                                    foreach ($option->values as $values):
                                                                        $selected = '';
                                                                        if ($value == $values->id) {
                                                                            $selected = ' selected="selected"';
                                                                        }
                                                                        ?>

                                                                        <option<?php echo $selected; ?> value="<?php echo $values->id; ?>">
                                                                            <?php
                                                                            echo($values->price != 0) ? ' (+' . format_currency($values->price) . ') ' : '';
                                                                            echo $values->name;
                                                                            ?>
                                                                        </option>

                                                                    <?php endforeach; ?>
                                                                </select>
                                                                <?php echo $required; ?>
                                                            </div>
                                                        <?php elseif ($option->type == 'radiolist'): ?>
                                                            <div>
                                                                <?php
                                                                foreach ($option->values as $values):

                                                                    $checked = '';
                                                                    if ($value == $values->id) {
                                                                        $checked = ' checked="checked"';
                                                                    }
                                                                    ?>
                                                                    <label class="radio">
                                                                        <input<?php echo $checked; ?> type="radio" name="option[<?php echo $option->id; ?>]" value="<?php echo $values->id; ?>"/>
                                                                        <?php
                                                                        echo($values->price != 0) ? '(+' . format_currency($values->price) . ') ' : '';
                                                                        echo $values->name;
                                                                        ?>
                                                                    </label>
                                                                <?php endforeach; ?>
                                                                <?php echo $required; ?>
                                                            </div>
                                                        <?php elseif ($option->type == 'checklist'): ?>
                                                            <div>
                                                                <?php
                                                                foreach ($option->values as $values):

                                                                    $checked = '';
                                                                    if (in_array($values->id, $value)) {
                                                                        $checked = ' checked="checked"';
                                                                    }
                                                                    ?>
                                                                    <label class="checkbox">
                                                                        <input<?php echo $checked; ?> type="checkbox" name="option[<?php echo $option->id; ?>][]" value="<?php echo $values->id; ?>"/>
                                                                        <?php
                                                                        echo($values->price != 0) ? '(' . format_currency($values->price) . ') ' : '';
                                                                        echo $values->name;
                                                                        ?>
                                                                    </label>

                                                                <?php endforeach; ?>
                                                            </div>
                                                            <?php echo $required; ?>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endforeach; ?>
                                            <?php endif; ?>

                                            <div>
                                                <?php if (!config_item('inventory_enabled') || config_item('allow_os_purchase') || !(bool) $product->track_stock || $product->quantity > 0) : ?>
                                                    <div>
                                                        <?php if (!$product->fixed_quantity) : ?>
                                                            <label><?php echo lang('quantity') ?></label>
                                                            <input style="height:30px;" type="text" name="quantity" value=""/>
                                                        <?php endif; ?>
                                                        <button class="btn btn-primary btn-large" type="submit" value="submit"><i class="icon-shopping-cart icon-white"></i> <?php echo lang('form_add_to_cart'); ?></button>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </fieldset>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if (!empty($product->excerpt)) : ?>
                            <div class="review" style="padding:10px;">
                                <?php echo $product->excerpt; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div><?php if (!empty($product->description)) : ?>
                <div class="wrapper mb-1">
                    <div id="tabs" class="htabs"><a class="selected" style="display: inline;" href="#tab-description">Description</a>
                        <!--                    <a style="display: inline;" href="#tab-review">Reviews (0)</a>-->
                    </div>
                </div>
            <?php endif ?>
            <div class="wrapper">
                <?php if (!empty($product->description)) : ?>
                    <div style="display: block;" id="tab-description" class="tab-content"><div class="std">
                            <div class="std">
                                <?php echo $product->description; ?>
                            </div>
                        </div>
                    </div>
                <?php endif ?>
                <!--                <div style="display: none;" id="tab-review" class="tab-content">
                                    <div id="review"><div class="content">There are no reviews for this product.</div>
                                    </div>
                                    <h2 id="review-title">Write a review</h2>
                                    <b>Your Name:</b><br>
                                    <input name="name" type="text">
                                    <br>
                                    <br>
                                    <b>Your Review:</b>
                                    <textarea name="text" cols="40" rows="8" style="width: 98%;"></textarea>
                                    <span style="font-size: 11px;"><span style="color: #FF0000;">Note:</span> HTML is not translated!</span><br>
                                    <br>
                                    <b>Rating:</b> <span>Bad</span>&nbsp;
                                    <input name="rating" value="1" type="radio">
                                    &nbsp;
                                    <input name="rating" value="2" type="radio">
                                    &nbsp;
                                    <input name="rating" value="3" type="radio">
                                    &nbsp;
                                    <input name="rating" value="4" type="radio">
                                    &nbsp;
                                    <input name="rating" value="5" type="radio">
                                    &nbsp; <span>Good</span><br>
                                    <br>
                                    <b>Enter the code in the box below:</b><br>
                                    <input name="captcha" type="text">
                                    <br>
                                    <img src="Dolor%20sit%20amet%20conse_files/index.jpeg" alt="" id="captcha"><br>
                                    <br>
                                    <div class="buttons">
                                        <div class="right"><a id="button-review" class="button"><span>Continue</span></a></div>
                                    </div>
                                </div>-->
            </div>          
            <?php if (!empty($product->related_products)): ?>
                <div class="related ">
                    <div class="box-product">  
                        <h3 style="margin-top:20px;"><?php echo lang('related_products_title'); ?></h3>
                        <ul>
                            <?php foreach ($product->related_products as $relate): ?>
                                <li class="related-info">
                                    <?php
                                    $photo = theme_img('no_picture.png', lang('no_image_available'));
                                    $relate->images = array_values((array) json_decode($relate->images));

                                    if (!empty($relate->images[0])) {
                                        $primary = $relate->images[0];
                                        foreach ($relate->images as $photo) {
                                            if (isset($photo->primary)) {
                                                $primary = $photo;
                                            }
                                        }

                                        $photo = '<img id="img_34" src="' . base_url('uploads/images/thumbnails/' . $primary->filename) . '" alt="' . $relate->seo_title . '"/>';
                                    }
                                    ?>
                                    <div class="image"><a href="<?php echo site_url($relate->slug); ?>"><?php echo $photo ?></a></div>
                                    <div class="name"><a href="<?php echo site_url($relate->slug); ?>"><?php echo $relate->name ?></a></div>
                                    <div class="price">
                                        <?php if ($relate->saleprice > 0): ?>
                                            <span class="price-new"><?php echo format_currency($relate->saleprice); ?></span><span class="price-old"><?php echo format_currency($relate->price); ?></span>
                                        <?php else : ?>
                                            <span class="price-new"><?php echo format_currency($relate->price); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="cart"><a onclick="addToCart('34');" class="button"><span>Add to Cart</span></a></div>
                                </li>
                            <?php endforeach ?>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>















<!--

<script type="text/javascript">
$('#button-cart').bind('click', function() {
        $.ajax({
            url: 'index.php?route=checkout/cart/add',
            type: 'post',
            data: $('.product-info input[type=\'text\'], .product-info input[type=\'hidden\'], .product-info input[type=\'radio\']:checked, .product-info input[type=\'checkbox\']:checked, .product-info select, .product-info textarea'),
            dataType: 'json',
            success: function(json) {
                $('.success, .warning, .attention, information, .error').remove();

                if (json['error']) {
                    if (json['error']['option']) {
                        for (i in json['error']['option']) {
                            $('#option-' + i).after('<span class="error">' + json['error']['option'][i] + '</span>');
                        }
                    }
                }

                if (json['success']) {
                    $('#notification').html('<div class="success" style="display: none;">' + json['success'] + '<span><img src="catalog/view/theme/theme064/image/close.png" alt="" class="close" /></span></div>');

                    $('.success').fadeIn('slow');

                    $('#cart-total').html(json['total']);

                    $('html, body').animate({scrollTop: 0}, 'slow');
                }
            }
        });
    });
//</script>
<script type="text/javascript">
    $('#review .pagination a').live('click', function() {
        $('#review').fadeOut('slow');

        $('#review').load(this.href);

        $('#review').fadeIn('slow');

        return false;
    });

    $('#review').load('index.php?route=product/product/review&product_id=29');

    $('#button-review').bind('click', function() {
        $.ajax({
            url: 'index.php?route=product/product/write&product_id=29',
            type: 'post',
            dataType: 'json',
            data: 'name=' + encodeURIComponent($('input[name=\'name\']').val()) + '&text=' + encodeURIComponent($('textarea[name=\'text\']').val()) + '&rating=' + encodeURIComponent($('input[name=\'rating\']:checked').val() ? $('input[name=\'rating\']:checked').val() : '') + '&captcha=' + encodeURIComponent($('input[name=\'captcha\']').val()),
            beforeSend: function() {
                $('.success, .warning').remove();
                $('#button-review').attr('disabled', true);
                $('#review-title').after('<div class="attention"><img src="catalog/view/theme/default/image/loading.gif" alt="" /> Please Wait!</div>');
            },
            complete: function() {
                $('#button-review').attr('disabled', false);
                $('.attention').remove();
            },
            success: function(data) {
                if (data['error']) {
                    $('#review-title').after('<div class="warning">' + data['error'] + '</div>');
                }

                if (data['success']) {
                    $('#review-title').after('<div class="success">' + data['success'] + '</div>');

                    $('input[name=\'name\']').val('');
                    $('textarea[name=\'text\']').val('');
                    $('input[name=\'rating\']:checked').attr('checked', '');
                    $('input[name=\'captcha\']').val('');
                }
            }
        });
    });
//</script> 
<script type="text/javascript">
    $('#tabs a').tabs();
//
<script type="text/javascript">
            $(function(){
                
                $('#slider1').Thumbelina({
                    $bwdBut:$('#slider1 .left'),    // Selector to left button.
                    $fwdBut:$('#slider1 .right')    // Selector to right button.
                });
                
                $('#slider2').Thumbelina({
                    $bwdBut:$('#slider2 .left'),    // Selector to left button.
                    $fwdBut:$('#slider2 .right')    // Selector to right button.
                });
                
                $('#slider3').Thumbelina({
                    orientation:'vertical',         // Use vertical mode (default horizontal).
                    $bwdBut:$('#slider3 .top'),     // Selector to top button.
                    $fwdBut:$('#slider3 .bottom')   // Selector to bottom button.
                });
              
            })
        </script>  
-->

