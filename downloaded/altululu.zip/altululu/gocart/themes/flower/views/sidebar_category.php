<?php if ($this->Customer_model->is_logged_in(false, false)): ?>
    <div class="box account">
        <div class="box-heading">Account</div>
        <div class="box-content">
            <ul class="acount">
                <li><a href="<?php echo site_url('secure/my_account'); ?>"><?php echo lang('my_account') ?></a> / <a href="<?php echo site_url('secure/my_account'); ?>"><?php echo lang('my_account') ?></a></li>
                <li><a href="<?php echo site_url('secure/my_account'); ?>">Forgotten Password</a></li>
                <li><a href="<?php echo site_url('secure/my_account'); ?>">My Account</a></li>
                <li><a href="<?php echo site_url('secure/my_account'); ?>">Wish List</a></li>
                <li><a href="<?php echo site_url('secure/my_account'); ?>">Order History</a></li>
                <li><a href="<?php echo site_url('secure/my_account'); ?>">Downloads</a></li>
                <li><a href="<?php echo site_url('secure/my_account'); ?>">Returns</a></li>
                <li><a href="<?php echo site_url('secure/my_account'); ?>">Transactions</a></li>
                <li><a href="<?php echo site_url('secure/my_account'); ?>">Newsletter</a></li>
            </ul>
        </div>
    </div>

    <script type="text/javascript">
        $(function() {
            $('.info-list li').last().addClass('last');
        });
    </script>
<?php else: ?>
    <div class="box info">
        <div class="box-heading">Information</div>
        <div class="box-content">

            <ul class="info-list">
                <li><a href="<?php echo site_url('about-us'); ?>">About</a></li>
                <li><a href="<?php echo site_url('delivery'); ?>">Delivery</a></li>
                <li><a href="<?php echo site_url('privacy-policy'); ?>">Privacy Policy</a></li>
                <li><a href="<?php echo site_url('terms-condition'); ?>">Terms &amp; Conditions</a></li>
                <li><a href="<?php echo site_url('contact-us'); ?>">Contact Us</a></li>
                <li><a href="<?php echo site_url('#'); ?>">Site Map</a></li>
            </ul>
        </div>
    </div>
<?php endif; ?>

<script type="text/javascript">
    (function($) {
        $.fn.equalHeights = function(minHeight, maxHeight) {
            tallest = (minHeight) ? minHeight : 0;
            this.each(function() {
                if ($(this).height() > tallest) {
                    tallest = $(this).height()
                }
            });
            if ((maxHeight) && tallest > maxHeight)
                tallest = maxHeight;
            return this.each(function() {
                $(this).height(tallest)
            })
        }
    })(jQuery)
    $(window).load(function() {
        if ($(".maxheight-spec").length) {
            $(".maxheight-spec").equalHeights()
        }
    })
</script>


<div class="box specials">
    <div class="box-heading special-heading">Specials</div>
    <div class="box-content">
        <div class="box-product">
            <span class="deal"></span>
            <ul>
                <?php foreach ($products_specials as $specials) : ?>

                    <?php
                    $photo = 'no_picture.png';
                    $specials->images = array_values($specials->images);

                    if (!empty($specials->images[0])) {
                        $primary = $specials->images[0];
                        foreach ($specials->images as $photo) {
                            if (isset($photo->primary)) {
                                $primary = $photo;
                            }
                        }

                        $photo = $primary->filename;
                        $alt = $specials->seo_title;
                    }
                    ?>
                    <li class="spec_1 ">
                        <div class="image2"><a href="<?php echo site_url($specials->slug); ?>"><img src="<?php echo base_url() . 'uploads/images/sthumbnails/' . $photo; ?>" alt="<?php echo $specials->slug; ?>"></a></div>
                        <div class="extra-wrap">
                            <div class="box-special-product">
                                <div class="name maxheight-feat"><a href="<?php echo site_url($specials->slug); ?>"><?php echo $specials->name; ?></a></div>
                                <!--<div class="description"><b>Notice</b>: Use of undefined constant php - assumed 'php' in <b>/var/www/html/wwwroot/opencart_40524/catalog/view/theme/theme064/template/module/special.tpl</b> on line <b>35</b></div>-->
                                <div class="price">
                                    <?php if ($specials->saleprice > 0): ?>
                                        <span class="price-new"><?php echo format_currency($specials->saleprice); ?></span><span class="price-old" style="font-size:12px;"><?php echo format_currency($specials->price); ?></span>
                                    <?php else : ?>
                                        <span class="price-new"><?php echo format_currency($specials->price); ?></span>
                                    <?php endif; ?>
                                </div>
                                            <!--<div class="cart"><a data-id=";" class="button addToCart"><span></span></a></div>-->
                            </div>
                        </div>
                        <div class="clear"></div>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</div>
<script type="text/javascript">
            (function($) {
                $.fn.equalHeights = function(minHeight, maxHeight) {
                    tallest = (minHeight) ? minHeight : 0;
                    this.each(function() {
                        if ($(this).height() > tallest) {
                            tallest = $(this).height()
                        }
                    });
                    if ((maxHeight) && tallest > maxHeight)
                        tallest = maxHeight;
                    return this.each(function() {
                        $(this).height(tallest)
                    })
                }
            })(jQuery)
    $(window).load(function() {
        if ($(".maxheight").length) {
            $(".maxheight").equalHeights()
        }
    });
</script>

<script type="text/javascript">
    $(document).ready(function() {
        $(function() {
            $('.new-products  li ').last().addClass('last');
        });
    });
</script>
<div class="box specials">
    <div class="box-heading special-heading">Latest</div>
    <div class="box-content">
        <div class="box-product">
            <span class="deal"></span>
            <ul>
                <?php foreach ($products_latest as $latest) : ?>

                    <?php
                    $photo = 'no_picture.png';
                    $latest->images = array_values($latest->images);

                    if (!empty($latest->images[0])) {
                        $primary = $latest->images[0];
                        foreach ($latest->images as $photo) {
                            if (isset($photo->primary)) {
                                $primary = $photo;
                            }
                        }

                        $photo = $primary->filename;
                        $alt = $latest->seo_title;
                    }
                    ?>
                    <li class="spec_1 ">
                        <div class="image2"><a href="<?php echo site_url($latest->slug); ?>"><img src="<?php echo base_url() . 'uploads/images/sthumbnails/' . $photo; ?>" alt="<?php echo $latest->slug; ?>"></a></div>
                        <div class="extra-wrap">
                            <div class="box-special-product">
                                <div class="name maxheight-feat"><a href="<?php echo site_url($latest->slug); ?>"><?php echo $latest->name; ?></a></div>
                                <!--<div class="description"><b>Notice</b>: Use of undefined constant php - assumed 'php' in <b>/var/www/html/wwwroot/opencart_40524/catalog/view/theme/theme064/template/module/special.tpl</b> on line <b>35</b></div>-->
                                <div class="price">
                                    <?php if ($latest->saleprice > 0): ?>
                                        <span class="price-new"><?php echo format_currency($latest->saleprice); ?></span><span class="price-old" style="font-size:12px;"><?php echo format_currency($latest->price); ?></span>
                                    <?php else : ?>
                                        <span class="price-new"><?php echo format_currency($latest->price); ?></span>
                                    <?php endif; ?>
                                </div>
                                            <!--<div class="cart"><a data-id=";" class="button addToCart"><span></span></a></div>-->
                            </div>
                        </div>
                        <div class="clear"></div>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</div>