                                    
<?php if (!empty($base_url) && is_array($base_url)): ?>

    <div class="breadcrumb" >
        <?php
        echo 'Home<span class="divider">/</span>';
        $url_path = '';
        $count = 1;
        foreach ($base_url as $bc):
            $url_path .= '/' . $bc;
            if ($count == count($base_url)):
                ?>
                <li class="active" style><?php echo $bc; ?></li>
            <?php else: ?>
                <li><a href="<?php echo site_url($url_path); ?>"><?php echo $bc; ?></a></li> <span class="divider">/</span>
            <?php
            endif;
            $count++;
        endforeach;
        ?>
    </div>

<?php endif; ?>

<?php if ($this->session->flashdata('message')): ?>
    <div class="alert alert-info">
        <a class="close" data-dismiss="alert">×</a>
        <?php echo $this->session->flashdata('message'); ?>
    </div>
<?php endif; ?>

<?php if ($this->session->flashdata('error')): ?>
    <div class="alert alert-error">
        <a class="close" data-dismiss="alert">×</a>
        <?php echo $this->session->flashdata('error'); ?>
    </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
    <div class="alert alert-error">
        <a class="close" data-dismiss="alert">×</a>
        <?php echo $error; ?>
    </div>
<?php endif; ?>





