<div class="main-container">
    <div id="container">
        <?php include_once 'breadcrumb.php'; ?>
        <div id="column-left">
            <?php include_once 'sidebar_category.php'; ?>
        </div>
        <div id="content">  
            <h1><?php echo isset($category->name) ? $category->name : 'Search Result'; ?></h1>
            <div class="category-info">

                <?php if (!empty($category->description)) : ?>
                    <div class="std">
                        <?php echo $category->description; ?>

                    </div>
                <?php endif; ?>
            </div>



            <?php
            $cols = 4;
            if (isset($category)):
                ?>
                <?php if (isset($this->categories[$category->id]) && count($this->categories[$category->id]) > 0): $cols = 3; ?>
                    <div class="box">
                        <div class="box-heading"><?php echo lang('subcategories'); ?></div>
                        <div class="box-content">

                            <div class="box-product box-subcat">

                                <ul> 

                                    <?php foreach ($this->categories[$category->id] as $subcategory): ?>
                                        <li class="product-list"><a href="<?php echo site_url(implode('/', $base_url) . '/' . $subcategory->slug); ?>"><?php echo($subcategory->name); ?></a></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>

                <?php endif; ?> 
            <?php endif; ?>
            <?php if (count($products) == 0): ?>
                <h2 style="margin:50px 0px; text-align:center;">
                    <?php
                    if ($search == 1)
                        echo lang('search_error');
                    else
                        echo lang('no_products');
                    ?>
                </h2>
            <?php else: ?>

                <div class="product-filter">
                    <div class="sort"><b>Sort By:</b>
                        <select onchange="window.location = '<?php echo site_url(uri_string()); ?>/' + $(this).val();">
                            <option value="?by=name/asc" selected="selected">Default</option>
                            <option<?php echo(!empty($_GET['by']) && $_GET['by'] == 'name/asc') ? ' selected="selected"' : ''; ?> value="?by=name/asc">Name (A - Z)</option>
                            <option<?php echo(!empty($_GET['by']) && $_GET['by'] == 'name/desc') ? ' selected="selected"' : ''; ?>  value="?by=name/desc">Name (Z - A)</option>
                            <option<?php echo(!empty($_GET['by']) && $_GET['by'] == 'price/asc') ? ' selected="selected"' : ''; ?>  value="?by=price/asc">Price (Low &gt; High)</option>
                            <option<?php echo(!empty($_GET['by']) && $_GET['by'] == 'price/desc') ? ' selected="selected"' : ''; ?>  value="?by=price/desc">Price (High &gt; Low)</option>
                        </select>
                    </div>
                    <div class="limit"><b>Show:</b>
                        <select onchange="window.location = '<?php echo site_url(uri_string()); ?>/' + $(this).val();">">
                            <option value="?limit=2" selected="selected">2</option>
                            <option<?php echo(!empty($_GET['limit']) && $_GET['limit'] == '10') ? ' selected="selected"' : ''; ?> value="?limit=10">10</option>
                            <option<?php echo(!empty($_GET['limit']) && $_GET['limit'] == '100') ? ' selected="selected"' : ''; ?> value="?limit=100">100</option>
                        </select>
                    </div>

                    <div class="display"><b>Display:</b> <div id="list_b"></div> <a id="grid_a" onclick="display('grid');">Grid</a></div>
                </div>

                <div class="product-list">
                    <ul>
                        <?php foreach ($products as $product): ?>


                            <li><div class="right">  <div class="price">

                                        <?php
                                        $photo = theme_img('no_picture.png', lang('no_image_available'));
                                        $product->images = array_values($product->images);

                                        if (!empty($product->images[0])) {
                                            $primary = $product->images[0];
                                            foreach ($product->images as $photo) {
                                                if (isset($photo->primary)) {
                                                    $primary = $photo;
                                                }
                                            }

                                            $photo = '<img src="' . base_url('uploads/images/thumbnails/' . $primary->filename) . '" alt="' . $product->seo_title . '"/>';
                                        }
                                        ?>

                                        <?php if ($product->saleprice > 0): ?>
                                            <span class="price-new"><?php echo format_currency($product->saleprice); ?></span>
                                            <span class="price-old"><?php echo format_currency($product->price); ?></span> 
                                        <?php else: ?>
                                            <span class="price-new"><?php echo format_currency($product->price); ?></span> 
                                            <span class="price-old"><br /><br /></span> 
                                        <?php endif; ?>
                                        <span class="price-tax"></span>

                                    </div>  
                                    <div class="cart">
                                        <a onclick="window.location = '<?php echo site_url($product->slug); ?>';" class="button"><span>View Product</span></a>
                                    </div>  
                            <!--        <div class="wishlist"><a class="tip" onclick="addToWishList('45');">Add to Wish List</a><span class="tooltip">Wishlist</span></div> 
                                    <div class="compare"><a class="tip2" onclick="addToCompare('45');">Add to Compare</a><span class="tooltip2">Compare</span></div>-->
                                </div>
                                <div class="left"><div class="image">
                                        <a href="<?php echo site_url(implode('/', $base_url) . '/' . $product->slug); ?>">
                                            <?php echo $photo; ?>
                                        </a>
                                    </div>
                                    <div class="name"><a href="<?php echo site_url(implode('/', $base_url) . '/' . $product->slug); ?>"><?php echo $product->name; ?></a></div> 
                                    <?php if ($product->excerpt != ''): ?>
                                        <div class="description">
                                            <div class="excerpt"><?php echo $product->excerpt; ?></div>          
                                        </div>
                                    <?php endif; ?>

                                    <?php if ((bool) $product->track_stock && $product->quantity < 1 && config_item('inventory_enabled')) { ?>
                                        <div class="stock_msg"><?php echo lang('out_of_stock'); ?></div>
                                    <?php } ?>
                                </div></li>   

                        <?php endforeach; ?>
                    </ul>
                </div>

            </div>
            <div>
                <div class="<?php echo ($cols == 4) ? 'span9' : 'span6'; ?>" style="float:right;width:460px;">
                    <?php echo $this->pagination->create_links(); ?>&nbsp;
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript"><!--
function display(view) {
        if (view == 'list') {
            $('.product-grid ').attr('class', 'product-list');

            $('.product-list ul li').each(function (index, element) {
                html = '<div class="right">';
                html += '  <div class="price">' + $(element).find('.price').html() + '</div>';
                html += '  <div class="cart">' + $(element).find('.cart').html() + '</div>';
                //html += '  <div class="wishlist">' + $(element).find('.wishlist').html() + '</div>';
                //html += '  <div class="compare">' + $(element).find('.compare').html() + '</div>';

                html += '</div>';

                html += '<div class="left">';

                var image = $(element).find('.image').html();

                if (image != null) {
                    html += '<div class="image">' + image + '</div>';
                }



                html += '  <div class="name">' + $(element).find('.name').html() + '</div>';
                html += '  <div class="description">' + $(element).find('.description').html() + '</div>';

                var rating = $(element).find('.rating').html();

                if (rating != null) {
                    html += '<div class="rating">' + rating + '</div>';
                }

                html += '</div>';


                $(element).html(html);
            });

            $('.display').html('<b>Display:</b> <div id="list_b"></div> <a id="grid_a" onclick="display(\'grid\');">Grid</a>');

            // $.cookie('display', 'list');
        } else {
            $('.product-list').attr('class', 'product-grid');

            $('.product-grid ul li').each(function (index, element) {
                html = '';

                var image = $(element).find('.image').html();

                if (image != null) {
                    html += '<div class="image">' + image + '</div>';
                }

                html += '<div class="name">' + $(element).find('.name').html() + '</div>';


                var price = $(element).find('.price').html();

                if (price != null) {
                    html += '<div class="price">' + price + '</div>';
                }

                html += '<div class="description">' + $(element).find('.description').html() + '</div>';

                var rating = $(element).find('.rating').html();

                if (rating != null) {
                    html += '<div class="rating">' + rating + '</div>';
                }

                html += '<div class="cart">' + $(element).find('.cart').html() + '</div>';
                //html += '<div class="wishlist">' + $(element).find('.wishlist').html() + '</div>';
                //html += '<div class="compare">' + $(element).find('.compare').html() + '</div>';

                $(element).html(html);
            });

            $('.display').html('<b>Display:</b> <a id="list_a" onclick="display(\'list\');">List</a>  <div id="grid_b"></div>');

            // $.cookie('display', 'grid');
        }
    }

    view = null;

    if (view) {
        display(view);
    } else {
        display('list');
    }
//--></script> 
<script type="text/javascript">
    (function ($) {
        $.fn.equalHeights = function (minHeight, maxHeight) {
            tallest = (minHeight) ? minHeight : 0;
            this.each(function () {
                if ($(this).height() > tallest) {
                    tallest = $(this).height()
                }
            });
            if ((maxHeight) && tallest > maxHeight)
                tallest = maxHeight;
            return this.each(function () {
                $(this).height(tallest)
            })
        }
    })(jQuery)
    $(window).load(function () {
        if ($(".cat-height").length) {
            $(".cat-height").equalHeights()
        }
    })
</script>