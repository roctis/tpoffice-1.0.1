<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

            <title><?php
                echo (!empty($seo_title)) ? $seo_title . ' - ' : '';
                echo $this->config->item('company_name');
                ?></title>


            <?php if (isset($meta)): ?>
                <?php echo $meta; ?>
            <?php else: ?>
                <meta name="Keywords" content="Shopping Cart, online store, Qatar Flowers Gifts">
                    <meta name="Description" content="Go Cart is an open source shopping cart built on the Code Igniter framework">
                    <?php endif; ?>
                    <?php echo theme_css('bootstrap.min.css', true); ?>
                    <?php echo theme_css('bootstrap-responsive.min.css', true); ?>
                    <?php echo theme_css('styles.css', true); ?>

                    <?php echo theme_css('bootstrap.min.css', true); ?>
                    <?php echo theme_css('thumbelina.css', true); ?>
                    <?php echo theme_css('stylesheet.css', true); ?>
                    <?php echo theme_css('cloud-zoom.css', true); ?>
                    <?php echo theme_css('superfish.css', true); ?>
                    <?php echo theme_css('slideshow.css', true); ?>

                    <?php echo theme_css('jquery_002.css', true); ?>
                    <?php echo theme_css('css_002.css', true); ?>
                    <?php echo theme_css('css.css', true); ?>

                    <?php echo theme_css('jquery-ui-1.css', true); ?>
                    <?php echo theme_css('colorbox.css', true); ?>



                    <!--[if  IE 8]>
                            <style>
                                    #menu #search input {
                                            padding-top:5px;
                                             padding-bottom:3px;
                                    }
                                    .featured ul li .image2:hover, .product-grid .image:hover { border-color:#000;}
                                    .success, #header #cart .content  { border:1px solid #e7e7e7;}
                                    #currency a  span { padding-top:1px;}
                            </style>
                    <![endif]-->
                    <!--[if  IE 9]>
                            <style>
                                    #currency a  span { padding-top:1px;}
                            </style>
                    <![endif]-->
                    <!--[if  IE 7]>
                    <link rel="stylesheet" type="text/css" href="catalog/view/theme/theme064/stylesheet/ie7.css" />
                    <![endif]-->
                    <!--[if lt IE 7]>
                    <link rel="stylesheet" type="text/css" href="catalog/view/theme/theme064/stylesheet/ie6.css" />
                    <script type="text/javascript" src="catalog/view/javascript/DD_belatedPNG_0.0.8a-min.js"></script>
                    <script type="text/javascript">
                    DD_belatedPNG.fix('#logo img');
                    </script>
                    <![endif]-->
                    <?php echo theme_js('jquery.js', true); ?>
                    <?php echo theme_js('jquery_171.js', true); ?>
                    <?php echo theme_js('bootstrap.min.js', true); ?>
                    <?php echo theme_js('jquery_prettyphoto.js', true); ?>
                    <?php echo theme_js('jquery-ui-1.js', true); ?>
                    <?php echo theme_js('unslider.min.js', true); ?>
                    <?php echo theme_js('tabs.js', true); ?>
                    <?php echo theme_js('squard.js', true); ?>
                    <?php echo theme_js('common.js', true); ?>
                    <?php echo theme_js('cloud-zoom.js', true); ?>
                    <?php echo theme_js('superfish.js', true); ?>
                    <?php echo theme_js('script.js', true); ?>
                    <?php
//with this I can put header data in the header instead of in the body.
                    if (isset($additional_header_info)) {
                        echo $additional_header_info;
                    }
                    ?>
                    </head>
                    <body>
                        <div class="main-shining">
                            <div id="header">
                                <div class="fleft">
                                    <div id="logo"><a href="<?php echo site_url(); ?>"><img src="<?php echo theme_url('assets/image/logo.png') ?>" title="qatar flower &amp gifts" alt="Flowers"></a></div>
                                </div>
                                <div class="fright" style="width:83%;">
                                    <div style="float:left;width:50%;height:130px;padding:50px 5% 15px 5%;">
                                        <?php $this->banners->show_collection(3, 2); ?>
                                    </div>
                                    <div style="float:right;width:40%;">
                                        <div id="search">
                                            <div class="button-search"></div>
                                            <span class="search-bg"><?php $search_att = array('id' => 'search_form'); ?>
                                                <?php echo form_open('cart/search', $search_att); ?>
                                                <input type="text" name="term" class="search-query span2" placeholder="<?php echo lang('search'); ?>"/>
                                                </form>
                                            </span>
                                        </div>
                                        <div class="clear"></div>
                                        <div class="header-top1">
                                            <?php if ($this->Customer_model->is_logged_in(false, false)): ?>
                                                <ul class="links">
                                                    <li><a class="" href="<?php echo site_url('secure/my_account'); ?>"><?php echo lang('my_account') ?></a></li>
                                                    <li><a class="" href="<?php echo site_url('cart/view_cart'); ?>"><?php echo lang('shopping_cart') ?></a></li>
                                                    <li><a class="" href="<?php echo site_url('secure/logout'); ?>"><?php echo lang('logout'); ?></a></li>
                                                    <li class="last"><a class="" href="<?php echo site_url('checkout'); ?>"><?php echo lang('check_out') ?></a></li>
                                                </ul>
                                            <?php else: ?>
                                                <div id="welcome">
                                                    Welcome visitor you can <a href="<?php echo site_url('secure/my_account'); ?>"><?php echo lang('login') ?></a> or <a href="<?php echo site_url('secure/register'); ?>">Create an account</a>							
                                                </div>
                                            <?php endif; ?>
                                            <div class="clear"></div>
                                            <div class="cart-position">
                                                <div class="cart-inner">
                                                    <div id="cart">



                                                        <div class="heading">
                                                            <b>Cart :&nbsp;</b>
                                                            <a>	
                                                                <span class="sc-button"></span>


                                                                <span id="cart-total"><?php echo $this->go_cart->total_items() ?> item(s) - <strong><?php echo format_currency($this->go_cart->total()); ?></strong></span>

                                                                <span class="clear"></span>
                                                            </a>
                                                        </div>

                                                        <div class="content">
                                                            <?php if ($this->go_cart->total_items() == 0) : ?>

                                                                <div class="empty">Your shopping cart is empty!</div>
                                                            <?php else : ?>
                                                                <span class="latest-added">Latest added product(s):</span>
                                                                <div class="mini-cart-info">
                                                                    <table class="cart">
                                                                        <tbody>
                                                                            <?php
                                                                            $subtotal = 0;

                                                                            foreach ($this->go_cart->contents() as $cartkey => $product):
                                                                                ?>
                                                                                <tr>
                                                                                    <?php
                                                                                    if ($product['images'] == 'false') {
                                                                                        $product['images'] = array();
                                                                                    } else {
                                                                                        $product['images'] = array_values((array) json_decode($product['images']));
                                                                                    }
                                                                                    ?>
                                                                                    <?php
                                                                                    $photo = theme_img('no_picture.png', lang('no_image_available'));
                                                                                    $product['images'] = array_values($product['images']);

                                                                                    if (!empty($product['images'][0])) {
                                                                                        $primary = $product['images'][0];
                                                                                        foreach ($product['images'] as $photo) {
                                                                                            if (isset($photo->primary)) {
                                                                                                $primary = $photo;
                                                                                            }
                                                                                        }

                                                                                        $photo = $primary->filename;
                                                                                        $alt = $product['seo_title'];
                                                                                    }
                                                                                    ?>
                                                                                    <td class = "image">
                                                                                        <a href = "<?php echo site_url($product['slug']); ?>"><img src = "<?php echo base_url() . 'uploads/images/sthumbnails/' . $photo ?>" alt = "<?php echo $product['images'][0]->alt ?>" title = "<?php echo $product['images'][0]->caption ?>"></a>
                                                                                    </td>
                                                                                    <td class = "name"><a href = "<?php echo site_url($product['slug']); ?>"><?php echo $product['name'];
                                                                                    ?></a>
                                                                                        <div>
                                                                                        </div>
                                                                                        <span class="quantity">x&nbsp;<?php echo $product['quantity'] ?></span>
                                                                                        <span class="total"><?php echo format_currency($product['price']); ?></span>

                                                                                    </td>
                                                                                    <!--td class="quantity">x&nbsp;</td-->
                                                                                    <!--td class="total"></td-->
                                                                          <!--          <td class="remove"><span><img src="Shopping%20Cart_files/close.png" alt="Remove" title="Remove" onclick="(getURLVar('route') == 'checkout/cart' || getURLVar('route') == 'checkout/checkout') ? location = 'index.php?route=checkout/cart&amp;remove=29' : $('#cart').load('index.php?route=module/cart&amp;remove=29' + ' #cart > *');"></span></td>-->
                                                                                </tr>
                                                                            <?php endforeach; ?>
                                                                        </tbody></table>
                                                                </div>
                                                                <div>
                                                                    <table class="total">
                                                                        <tbody><tr>
                                                                                <td class="total-right" align="right"><b>Sub-Total:</b></td>
                                                                                <td class="total-left" align="left"><span class="t-price"><?php echo format_currency($this->go_cart->subtotal()); ?></span></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td class="total-right" align="right"><b>Total:</b></td>
                                                                                <td class="total-left" align="left"><span class="t-price"><?php echo format_currency($this->go_cart->total()); ?></span></td>
                                                                            </tr>
                                                                        </tbody></table>
                                                                </div>
                                                                <div class="checkout"><a class="button" href= "<?php echo site_url('cart/view_cart'); ?>"><span>View Cart</span></a> <a class="button" href="<?php echo site_url('checkout'); ?>"><span><?php echo lang('check_out') ?></span></a></div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div id="currency"><span>
                                                            Currency</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div></div>
                                <div class="clear"></div>
                            </div>
                            <div id="menu">
                                <script type="text/javascript">
                                    $(document).ready(function () {

                                        $('.menu ul li').last().addClass('last');
                                        $('.menu ul li li').last().addClass('last');
                                    });

                                </script>
                                <ul class="menu sf-js-enabled">
                                    <li class="cat_1">
                                        <a href="<?php echo site_url() . "birthday" ?>">Birthday</a>
                                    </li>
                                    <li class="cat_2">
                                        <a href="<?php echo site_url() . "occasion" ?>">Occasion</a>
                                    </li>
                                    <li class="cat_3">
                                        <a href="<?php echo site_url() . "flowers" ?>">Flowers</a>
                                    </li>
                                    <li class="cat_4">
                                        <a href="<?php echo site_url() . "gifts" ?>">Gifts</a>
                                    </li>
                                    <li class="cat_5">
                                        <a href="<?php echo site_url() . "specials" ?>">Specials</a>
                                    </li>
                                    <li class="cat_6">
                                        <a href="#"><?php echo lang('catalog') ?></a>
                                        <ul style="display: none; visibility: hidden;">		
                                            <?php foreach ($this->categories[0] as $cat_menu): ?>
                                                <li><a class="screenshot1" href="<?php echo site_url($cat_menu->slug); ?>"><?php echo $cat_menu->name; ?></a></li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </li>
                                    <li class="cat_5">
                                        <a href="<?php echo site_url() . "specials" ?>">Specials</a>
                                        <ul style="display: none; visibility: hidden;">		
                                            <?php foreach ($this->categories[0] as $cat_menu): ?>
                                                <li><a class="screenshot1" href="<?php echo site_url($cat_menu->slug); ?>"><?php echo $cat_menu->name; ?></a></li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </li>
                                </ul>

                                <div class="clear"></div>
                            </div>


