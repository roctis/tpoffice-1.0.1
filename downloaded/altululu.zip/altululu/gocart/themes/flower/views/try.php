<?php
echo "<pre>";
print_r($products_specials);
exit;

?>

