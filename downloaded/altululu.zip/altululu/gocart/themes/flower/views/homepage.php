<!--<div class="row">
    <div class="span12">
<?php // $this->banners->show_collection(1, 5);?>
    </div>
</div>-->

<?php // $this->banners->show_collection(2, 3, '3_box_row');?>
<script type="text/javascript" charset="utf-8">
    $(window).load(function () {
        $('.ban').unslider({
            dots: true
        });
    });
</script>
<div class="header-modules">
    <script type="text/javascript">
        (function ($) {
            $.fn.equalHeights = function (minHeight, maxHeight) {
                tallest = (minHeight) ? minHeight : 0;
                this.each(function () {
                    if ($(this).height() > tallest) {
                        tallest = $(this).height()
                    }
                });
                if ((maxHeight) && tallest > maxHeight)
                    tallest = maxHeight;
                return this.each(function () {
                    $(this).height(tallest)
                })
            }
        })(jQuery)
        $(window).load(function () {
            if ($(".maxheight-spec").length) {
                $(".maxheight-spec").equalHeights()
            }
        })
    </script>
    <?php
    $no_of_ul = (int) count($special_boxes) / 3;
    for ($i = 0; $i < $no_of_ul; $i++):
        ?>              
        <div class="box specials">
            <div class="box-heading special-heading">Specials</div>
            <div class="box-content">
                <div class="box-product" style="display:block;height:386px;overflow:hidden">
<!--                    <span class="deal" style="z-index:1111"></span>-->
                    <ul>
                        <?php for ($j = 1; $j <= 3; $j++): ?>
                        <?php if (($i*3+$j)<=count($special_boxes)): ?>
                            <li class="spec_<?php echo $j ?> ">
                                <div class="ribbon"><span>bestseller</span></div>
                                <div class="ban">
                                    <ul>
                                        <?php 
                                        
                                            foreach ($special_boxes[$i*3+$j-1] as $products): ?>             
                                            <li style="margin:0px;">
                                                <?php
                                                $photo = 'no_picture.png';
                                                $products->images = array_values($products->images);

                                                if (!empty($products->images[0])) {
                                                    $primary = $products->images[0];
                                                    foreach ($products->images as $photo) {
                                                        if (isset($photo->primary)) {
                                                            $primary = $photo;
                                                        }
                                                    }

                                                    $photo = $primary->filename;
                                                    $alt = $products->seo_title;
                                                }
                                                ?>

                                                <div class="image2">
                                                    <a href="<?php echo site_url($products->slug); ?>">
                                                        <img src="<?php echo base_url() . 'uploads/images/medium/' . $photo; ?>" alt="<?php echo $alt; ?>"></a>
                                                </div>
                                                <div class="extra-wrap">
                                                    <div class="box-special-product">
                                                        <div class="name maxheight-feat"><a href="<?php echo site_url($products->slug); ?>"><?php echo $products->name; ?></a></div>
                                                        <!--<div class="description"><b>Notice</b>: Use of undefined constant php - assumed 'php' in <b>/var/www/html/wwwroot/opensource_40524/catalog/viewrt/theme/theme064/template/module/special.tpl</b> on line <b>35</b></div>-->
                                                        <div class="price"><?php $price = ($products->saleprice > 0) ? format_currency($products->saleprice) : format_currency($products->price) ?>
                                                            <span class="price-new"><?php echo $price; ?></span><span class="price-old">£127.98</span> 
                                                        </div>
                                              <!--<div class="cart"><a data-id=";" class="button addToCart"><span></span></a></div>-->
                                                    </div>
                                                </div>
                                                <div class="clear"></div>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                                </li>
                            <?php endif;?>
                        <?php endfor; ?>
                    </ul>

                </div>
            </div>                  
        </div>
    <?php endfor; ?>
</div>               
<div class="clear"></div>
<div class="main-container">
    <p style="display: block;" id="back-top"> <a href="#top"><span></span></a> </p>
    <div id="container">
        <div id="notification"> </div>

        <div id="content">
            <div class="welcome" style='height:358px;'><!---->
                <span class="font-1">Welcome</span>
                <span class="font-2">to our store!</span>
                <div style="height:200px;overflow:hidden;">
                    <?php echo $about->content; ?>
                </div><br />
                <div class="buttons">
                    <div><a href="<?php echo site_url($about->slug); ?>"><span class="btn btn-primary btn-large">About us &gt;&gt;</span></a></div>
                </div>
            </div>
            <div id="banner0" class="banner" style="height:348px;">
                <div><?php $this->banners->show_collection(1, 5); ?>
                </div>
            </div>

            <script type="text/javascript">
                $(document).ready(function () {
                    $(function () {
                        $('.new-products  li ').last().addClass('last');
                    });
                });
            </script>
            <div class="box new-products" style='height:366px'>
                <div class="box-heading">Latest</div>
                <div class="box-content">
                    <div class="box-product">
                        <ul style=""><br />
                            <?php foreach ($products_latest as $latest) : ?>

                                <?php
                                $photo = 'no_picture.png';
                                $latest->images = array_values($latest->images);

                                if (!empty($latest->images[0])) {
                                    $primary = $latest->images[0];
                                    foreach ($latest->images as $photo) {
                                        if (isset($photo->primary)) {
                                            $primary = $photo;
                                        }
                                    }

                                    $photo = $primary->filename;
                                    $alt = $latest->seo_title;
                                }
                                ?>

                                <li> <div class="image2"><a href="<?php echo site_url($latest->slug); ?>"><img src="<?php echo base_url() . 'uploads/images/sthumbnails/' . $photo; ?>" alt="<?php echo $latest->slug; ?>"></a></div>
                                    <div class="extra-wrap">
                                        <div style="height: 22px;" class="name maxheight"><a href="<?php echo site_url($latest->slug); ?>"><?php echo $latest->name; ?></a></div>
                                        <div class="price">
                                            <?php if ($latest->saleprice > 0): ?>
                                                <span class="price-new"><?php echo format_currency($latest->saleprice); ?></span><span class="price-old"><?php echo format_currency($latest->price); ?></span>
                                            <?php else : ?>
                                                <span class="price-new"><?php echo format_currency($latest->price); ?></span>
                                            <?php endif; ?>
                                        </div>
    <!--<div class="cart"><a data-id=";" class="button addToCart"><span><b>Notice</b>: Use of undefined constant php - assumed 'php' in <b>/var/www/html/wwwroot/opensource_40524/catalog/view/theme/theme064/template/module/latest.tpl</b> on line <b>53</b></span></a></div>-->
                                    </div>
                                    <div class="clear"></div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div><h1 style="display: none;">Flowers</h1>
        </div>
    </div>
    <div class="clear"></div>
</div>

