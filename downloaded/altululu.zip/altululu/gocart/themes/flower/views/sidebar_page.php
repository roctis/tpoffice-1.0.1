<?php if ($this->Customer_model->is_logged_in(false, false)): ?>
    <div class="box account">
        <div class="box-heading">Account</div>
        <div class="box-content">
            <ul class="acount">
                <li><a href="<?php echo site_url('secure/my_account'); ?>"><?php echo lang('my_account') ?></a> / <a href="<?php echo site_url('secure/my_account'); ?>"><?php echo lang('my_account') ?></a></li>
                <li><a href="<?php echo site_url('secure/my_account'); ?>">Forgotten Password</a></li>
                <li><a href="<?php echo site_url('secure/my_account'); ?>">My Account</a></li>
                <li><a href="<?php echo site_url('secure/my_account'); ?>">Wish List</a></li>
                <li><a href="<?php echo site_url('secure/my_account'); ?>">Order History</a></li>
                <li><a href="<?php echo site_url('secure/my_account'); ?>">Downloads</a></li>
                <li><a href="<?php echo site_url('secure/my_account'); ?>">Returns</a></li>
                <li><a href="<?php echo site_url('secure/my_account'); ?>">Transactions</a></li>
                <li><a href="<?php echo site_url('secure/my_account'); ?>">Newsletter</a></li>
            </ul>
        </div>
    </div>

    <script type="text/javascript">
        $(function() {
            $('.info-list li').last().addClass('last');
        });
    </script>
<?php else: ?>
    <div class="box info">
        <div class="box-heading">Information</div>
        <div class="box-content">

            <ul class="info-list">
                <li><a href="<?php echo site_url('about-us'); ?>">About</a></li>
                <li><a href="<?php echo site_url('delivery'); ?>">Delivery</a></li>
                <li><a href="<?php echo site_url('privacy-policy'); ?>">Privacy Policy</a></li>
                <li><a href="<?php echo site_url('terms-condition'); ?>">Terms &amp; Conditions</a></li>
                <li><a href="<?php echo site_url('contact-us'); ?>">Contact Us</a></li>
                <li><a href="<?php echo site_url('#'); ?>">Site Map</a></li>
            </ul>
        </div>
    </div>
<?php endif; ?>
  