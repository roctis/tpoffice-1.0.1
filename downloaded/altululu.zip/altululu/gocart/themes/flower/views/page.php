<div class="main-container">
    <div id="container">
        <?php include_once 'breadcrumb.php';?>
    <div id="column-left">
        <?php include_once 'sidebar_page.php';?>
    </div>
        <div id="content">  
        <h1><?php echo $page_title ?></h1>
        <div class="box-container">
            <div class="about-page">
                <?php echo $page->content; ?>
            </div>
        </div>
    </div>
    
</div>
</div>