<div class="row">
    <div class="span12">
        <?php $this->banners->show_collection(1, 5);?>
    </div>
</div>

<?php $this->banners->show_collection(2, 3, '3_box_row');?>