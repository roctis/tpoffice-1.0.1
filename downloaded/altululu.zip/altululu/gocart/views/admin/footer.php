    <hr/>
    <footer>
        <div style="text-align:center;"><a href="http://qatarflowersandgifts.com" target="_blank">qatarflowersandgifts.com</a></div>
    </footer>
</div>

</body>
</html>